# MissionCart + SYNESIS project plan

## Scope and guardrails

MissionCart and the future SYNESIS operations interface share one repository. All catalogue, payment, and transaction data in the current project is synthetic. No real payment provider, bank, marketplace, customer account, or commerce-platform connection exists or is implied.

## Phase 1 — MissionCart storefront foundation — complete

- Responsive React/Vite/TypeScript storefront with catalogue search, category filters, product details, image fallbacks, and browser-local bag controls.
- Sample data remains available only when no API origin has been configured.

## Phase 2 — Shared transaction backend — complete and verified

- FastAPI + SQLite backend with isolated database access and a seeded synthetic catalogue.
- MissionCart catalogue, checkout, order-listing, order-detail, and order-event endpoints.
- Orders store ID, status, INR total, source platform, simulated payment reference, creation time, and item snapshots.
- Transaction events store ID, transaction ID, event type, deterministic event order, timestamp, state, source platform, order ID, and payment reference.
- Idempotent checkout requires `Idempotency-Key`; exact retries return the original order without duplicate events, while changed requests using the same key fail safely.
- Storefront uses configured backend responses for catalogue, checkout, and order history; configured API failures are visible and retryable.
- Seven backend tests, frontend lint/build, live API checks, duplicate-retry checks, and a browser storefront checkout were run successfully on 13 October 2026.

## Phase 3 — Single-host monitoring, fault injection, diagnosis — complete and verified (see BUILD_STATUS.md)

- Payment records separate from orders; canonical event log extended with `PAYMENT_CAPTURED` and `ORDER_CREATION_FAILED`.
- Development-only fault injection, deterministic detection of payment-without-order, persisted incidents with evidence and probable cause.
- SYNESIS operations page at `/synesis` on the same frontend, backend and database.

## Phase 4 — Safe recovery and auditability — partly complete

- Done: recovery that retries order creation only, blocks on non-SUCCESS payments, verifies final state before resolving, and records every attempt.
- Not done: authentication and approval roles, immutable/tamper-evident audit history (attempts are stored but not locked), recovery for other incident types.

## Phase 5 — Second source adapter — not started

- Add a simulated Store B adapter with a different input format.
- Verify that MissionCart and Store B flow through the same normalization and monitoring engine.

## Phase 6 — SYNESIS operations dashboard — minimal version done in Phase 3

- Done minimally: counts, transactions, incidents, investigation, recovery button. Remaining: richer explorer, filtering and charts. Original goal: transaction explorer, incidents, investigations, evidence timeline, recovery controls, results, audit history, and database-derived reliability metrics.

## Phase 7 — Further validation and local-network readiness — out of scope for now (single-host only)

- Test the mandatory purchase-to-recovery scenario end to end.
- Configure local-network frontend/API access and document IP/port/CORS requirements.
- Reassess storage before any public deployment; migrate from SQLite to managed PostgreSQL when deployment persistence or concurrency requires it.
