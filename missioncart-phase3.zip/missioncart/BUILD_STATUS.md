# Build status

## Phase 3 — single-host monitoring, diagnosis and recovery (verified 13 October 2026)

Everything runs on one machine: one FastAPI backend, one SQLite database, one Vite frontend. MissionCart is at `/`, the SYNESIS operations page is at `/synesis`. No networking, LAN, cloud or deployment work was done.

### What was built

- **Payment record.** Checkout now captures the simulated payment in a `payments` table (authoritative status `SUCCESS`/`FAILED`/`PENDING`/`UNKNOWN`, item snapshot, idempotency key) as its own transaction, then creates the order in a second transaction. This is the window in which a real checkout can fail.
- **Event model.** Checkout records `CHECKOUT_ACCEPTED`, `PAYMENT_CAPTURED`, then `ORDER_CONFIRMED` (or `ORDER_CREATION_FAILED`, or `RECOVERY_ORDER_CREATED`). `transaction_events.order_id` is now nullable (no order exists yet when order creation fails) and has a `detail` column. Existing databases are migrated in place on startup; existing orders get a derived `payments` row.
- **Fault injection (development only).** Needs `SYNESIS_ENABLE_FAULT_INJECTION=true` and `SYNESIS_ENV` not equal to `production`; otherwise the toggle endpoint returns 403. Off by default and reset on every backend restart. When on, checkout fails with HTTP 503 after the payment and its events are persisted.
- **Detection.** `POST /api/synesis/scan` finds payments with status SUCCESS and no order (`PAID_NO_ORDER`) and PENDING/UNKNOWN payments with no order (`PAYMENT_STATE_UNCERTAIN`). A partial unique index allows only one open incident per transaction and type, so repeated scans never duplicate. A payment with no recorded failure event is only flagged after a grace period (`SYNESIS_SCAN_GRACE_SECONDS`, default 30).
- **Diagnosis.** Each incident stores evidence facts taken from the payments table, orders table and event log, plus a probable cause worded as evidence-based, not proof.
- **Recovery.** `POST /api/synesis/incidents/{id}/recover` retries order creation only and never creates a payment. It is blocked unless the payment status is SUCCESS, does nothing if an order already exists, fails (incident stays open) while the fault is still active, and resolves the incident only after verifying: exactly one order for the payment, exactly one payment record, order CONFIRMED, order total equals payment amount, same idempotency key, item lines sum to the payment amount. A failed verification rolls the order back. Every attempt is recorded in `recovery_attempts`.
- **Customer retry.** Retrying checkout with the same Idempotency-Key after a failure reuses the captured payment and creates only the order. SYNESIS marks an open incident `OBSERVED_CONSISTENT` if an order appears this way.
- **Dashboard (`/synesis`).** Counts, transaction table (order ID, transaction ID, payment status, order status, timestamp, source, consistency), incident list, investigation view (evidence, probable cause, event timeline, recovery history), latest events, fault toggle, recover button. All values come from the API; nothing is hardcoded. It auto-scans every 4 seconds.

### Verification performed

- `python3 -m unittest discover -s backend/tests -v`: **16 tests passed** (7 original, 9 new in `test_synesis.py`).
- Two original assertions were changed on purpose: a checkout now records 3 events instead of 2 because of the new `PAYMENT_CAPTURED` event.
- New tests cover: successful checkout with persisted events, fault off by default and blocked in production, fault leaving payment without order and creating an incident, no duplicate incidents over repeated scans, customer retry never charging twice, recovery creating the order only and verifying final state, recovery refused while the fault is active, recovery blocked for UNKNOWN/PENDING/FAILED payments, uncertain-payment incidents, double recovery rejected (409).
- `npm run lint` and `npm run build` passed (run in a clean copy with Linux dependencies, because the macOS `node_modules` in the archive cannot run in the Linux sandbox; the code was not changed for this).
- Migration was checked on a copy of the shipped `missioncart.sqlite3`: 2 orders and 4 events preserved, 2 payment rows derived, 0 false incidents.
- Live run against a real `uvicorn` server with curl: normal checkout 201; fault on; checkout returned 503; three scans created exactly one incident; recovery with fault still on returned FAILED and left the incident open; recovery after turning the fault off returned SUCCEEDED with all verification checks ok and resolved the incident; a second recovery returned 409; final counts were consistent.
- Browser run (headless Chromium, Vite dev server): storefront loaded; fault toggled from `/synesis`; MissionCart checkout showed the "payment recorded, retry will not charge you again" message; `/synesis` detected the incident and showed evidence and timeline; recovery succeeded and the incident showed as resolved; no page errors.

### Not verified / known limits

- Not run on the target MacBook; run commands are in README.md.
- Fault injection is a switch inside the application's own checkout, so it simulates the failure rather than using a real broken dependency.
- Only two incident types exist. There is no check for an order whose payment is missing.
- Concurrency hardening is limited to SQLite `BEGIN IMMEDIATE` and unique constraints. Detection is polled, not event-driven.
- Recovery needs a person to click the button; nothing recovers automatically.
- No authentication on any endpoint, including the SYNESIS API. Local use only.
- Orders created before Phase 3 have no item snapshot, so they could not be rebuilt by recovery (they have orders anyway).
- Store B, LLM diagnosis, advanced analytics, LAN access and deployment were skipped as instructed.

## Earlier phases

Phase 1 (storefront) and Phase 2 (FastAPI + SQLite backend, idempotent checkout, order history, transaction events) are described in PROJECT_PLAN.md. Their original verification notes are superseded by the Phase 3 results above.
