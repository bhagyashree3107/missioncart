import { apiClient } from '../services/apiClient'
import type { TransactionEvent } from '../types/orders'

export type Counts = {
  transactions: number
  ordersConfirmed: number
  paidWithoutOrder: number
  openIncidents: number
  resolvedIncidents: number
  recoveryAttempts: number
  verifiedRecoveries: number
}

export type TransactionRow = {
  transactionId: string
  paymentReference: string
  paymentStatus: string
  amount: number
  currency: string
  sourcePlatform: string
  timestamp: string
  orderId: string | null
  orderStatus: string
  consistency: 'CONSISTENT' | 'MISMATCH' | 'OTHER'
  incidentId: string | null
}

export type Incident = {
  id: string
  transactionId: string
  paymentReference: string
  type: string
  severity: string
  status: 'OPEN' | 'RESOLVED'
  summary: string
  probableCause: string
  evidence: string[]
  detectedAt: string
  resolvedAt: string | null
  resolution: string | null
}

export type RecoveryAttempt = {
  id: string
  attemptedAt: string
  outcome: 'SUCCEEDED' | 'BLOCKED' | 'FAILED'
  reason: string
  orderId: string | null
  verified: boolean
}

export type FaultStatus = { available: boolean; enabled: boolean }

export type Overview = {
  counts: Counts
  transactions: TransactionRow[]
  incidents: Incident[]
  recentEvents: TransactionEvent[]
  faultInjection: FaultStatus
}

export type IncidentDetail = {
  incident: Incident
  timeline: TransactionEvent[]
  attempts: RecoveryAttempt[]
  order: { id: string; status: string; total: number } | null
}

export type RecoveryResult = { outcome: RecoveryAttempt['outcome']; reason: string; orderId: string | null; incident: Incident }

export const synesisService = {
  overview: () => apiClient.get<Overview>('/api/synesis/overview'),
  scan: () => apiClient.post<{ created: string[]; resolved: string[] }>('/api/synesis/scan', {}),
  incident: (id: string) => apiClient.get<IncidentDetail>(`/api/synesis/incidents/${id}`),
  recover: (id: string) => apiClient.post<RecoveryResult>(`/api/synesis/incidents/${id}/recover`, {}),
  setFault: (enabled: boolean) => apiClient.post<FaultStatus>('/api/synesis/fault-injection', { body: { enabled } }),
}
