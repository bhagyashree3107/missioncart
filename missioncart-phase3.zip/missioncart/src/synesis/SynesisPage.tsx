import { useCallback, useEffect, useState } from 'react'
import { ApiError } from '../services/apiClient'
import {
  synesisService,
  type IncidentDetail,
  type Overview,
  type RecoveryResult,
} from './synesisService'

const time = (iso: string) => new Date(iso).toLocaleTimeString([], { hour12: false })
const short = (id: string | null) => (id ? id.slice(0, 12) + '…' : '—')
const message = (error: unknown) => (error instanceof ApiError ? error.message : error instanceof Error ? error.message : 'Request failed.')

export default function SynesisPage() {
  const [overview, setOverview] = useState<Overview | null>(null)
  const [error, setError] = useState('')
  const [selected, setSelected] = useState<string | null>(null)
  const [detail, setDetail] = useState<IncidentDetail | null>(null)
  const [recovery, setRecovery] = useState<RecoveryResult | null>(null)
  const [busy, setBusy] = useState(false)

  const refresh = useCallback(async (scan: boolean) => {
    try {
      if (scan) await synesisService.scan()
      setOverview(await synesisService.overview())
      setError('')
    } catch (e) {
      setError(message(e))
    }
  }, [])

  useEffect(() => {
    const first = window.setTimeout(() => void refresh(true), 0)
    const timer = window.setInterval(() => void refresh(true), 4000)
    return () => {
      window.clearTimeout(first)
      window.clearInterval(timer)
    }
  }, [refresh])

  useEffect(() => {
    if (!selected) return
    let cancelled = false
    synesisService.incident(selected).then((d) => { if (!cancelled) setDetail(d) }).catch((e) => setError(message(e)))
    return () => { cancelled = true }
  }, [selected, overview])

  const toggleFault = async () => {
    if (!overview) return
    try {
      await synesisService.setFault(!overview.faultInjection.enabled)
      await refresh(false)
    } catch (e) {
      setError(message(e))
    }
  }

  const recover = async () => {
    if (!selected) return
    setBusy(true)
    try {
      setRecovery(await synesisService.recover(selected))
      await refresh(true)
    } catch (e) {
      setError(message(e))
    } finally {
      setBusy(false)
    }
  }

  const c = overview?.counts
  const fault = overview?.faultInjection

  return (
    <main className="syn">
      <header className="syn-head">
        <div>
          <h1>SYNESIS <span>operations</span></h1>
          <p>Reads the same local database as MissionCart. Auto-scans every 4 seconds.</p>
        </div>
        <div className="syn-links">
          <a href="/">← MissionCart</a>
          <button type="button" onClick={() => void refresh(true)}>Scan now</button>
        </div>
      </header>

      {error && <div className="syn-error" role="alert">{error}</div>}
      {!overview && !error && <p>Loading…</p>}

      {overview && c && (
        <>
          <section className="syn-counts" aria-label="Counts from database records">
            <Stat label="Transactions" value={c.transactions} />
            <Stat label="Orders confirmed" value={c.ordersConfirmed} />
            <Stat label="Paid, no order" value={c.paidWithoutOrder} warn={c.paidWithoutOrder > 0} />
            <Stat label="Open incidents" value={c.openIncidents} warn={c.openIncidents > 0} />
            <Stat label="Resolved" value={c.resolvedIncidents} />
            <Stat label="Verified recoveries" value={`${c.verifiedRecoveries}/${c.recoveryAttempts}`} />
          </section>

          <section className="syn-fault">
            <strong>Fault injection (development only)</strong>
            {fault?.available ? (
              <>
                <span>{fault.enabled ? 'ON — next checkout fails after payment is captured' : 'OFF'}</span>
                <button type="button" onClick={() => void toggleFault()}>{fault.enabled ? 'Turn off' : 'Turn on'}</button>
              </>
            ) : (
              <span>Unavailable. Start the backend with SYNESIS_ENABLE_FAULT_INJECTION=true (not in production).</span>
            )}
          </section>

          <div className="syn-grid">
            <section>
              <h2>Incidents</h2>
              {overview.incidents.length === 0 ? <p className="syn-muted">No incidents recorded.</p> : (
                <ul className="syn-list">
                  {overview.incidents.map((i) => (
                    <li key={i.id}>
                      <button type="button" className={selected === i.id ? 'on' : ''} onClick={() => { setSelected(i.id); setRecovery(null) }}>
                        <span className={`pill ${i.status.toLowerCase()}`}>{i.status}</span>
                        <b>{i.type}</b>
                        <small>{time(i.detectedAt)} · {short(i.transactionId)}</small>
                        <span>{i.summary}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section>
              <h2>Investigation</h2>
              {!selected || !detail || detail.incident.id !== selected ? (
                <p className="syn-muted">Select an incident to see evidence, timeline and recovery options.</p>
              ) : (
                <div className="syn-detail">
                  <h3>{detail.incident.summary}</h3>
                  <p><b>Probable cause.</b> {detail.incident.probableCause}</p>
                  <h4>Evidence</h4>
                  <ul>{detail.incident.evidence.map((f) => <li key={f}>{f}</li>)}</ul>
                  <h4>Timeline</h4>
                  <ol className="syn-timeline">
                    {detail.timeline.map((e) => (
                      <li key={e.id} className={e.state === 'FAILED' ? 'bad' : ''}>
                        <time>{time(e.occurredAt)}</time> <b>{e.eventType}</b> <em>{e.state}</em>
                        {e.detail && <small> — {e.detail}</small>}
                      </li>
                    ))}
                  </ol>
                  {detail.attempts.length > 0 && (
                    <>
                      <h4>Recovery history</h4>
                      <ul>{detail.attempts.map((a) => (
                        <li key={a.id}><time>{time(a.attemptedAt)}</time> <b>{a.outcome}</b>{a.verified ? ' (verified)' : ''} — {a.reason}</li>
                      ))}</ul>
                    </>
                  )}
                  {detail.incident.status === 'OPEN' ? (
                    <button type="button" className="primary" disabled={busy} onClick={() => void recover()}>
                      {busy ? 'Recovering…' : 'Recover (create order only, no new charge)'}
                    </button>
                  ) : (
                    <p className="syn-ok">Resolved{detail.incident.resolution ? `: ${detail.incident.resolution}` : ''}</p>
                  )}
                  {recovery && <p className={`syn-result ${recovery.outcome.toLowerCase()}`}>{recovery.outcome}: {recovery.reason}</p>}
                </div>
              )}
            </section>
          </div>

          <section>
            <h2>Recent transactions</h2>
            <div className="syn-scroll">
              <table>
                <thead><tr><th>Time</th><th>Transaction</th><th>Order</th><th>Payment</th><th>Order status</th><th>Amount</th><th>Source</th><th>State</th></tr></thead>
                <tbody>
                  {overview.transactions.map((t) => (
                    <tr key={t.transactionId} className={t.consistency === 'MISMATCH' ? 'bad' : ''}>
                      <td>{time(t.timestamp)}</td><td>{short(t.transactionId)}</td><td>{short(t.orderId)}</td>
                      <td>{t.paymentStatus}</td><td>{t.orderStatus}</td><td>{t.currency} {t.amount}</td>
                      <td>{t.sourcePlatform}</td>
                      <td>{t.incidentId ? <button type="button" className="link" onClick={() => { setSelected(t.incidentId); setRecovery(null) }}>{t.consistency} · incident</button> : t.consistency}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section>
            <h2>Latest transaction events</h2>
            <div className="syn-scroll">
              <table>
                <thead><tr><th>Time</th><th>Event</th><th>State</th><th>Transaction</th><th>Order</th><th>Source</th></tr></thead>
                <tbody>
                  {overview.recentEvents.map((e) => (
                    <tr key={e.id} className={e.state === 'FAILED' ? 'bad' : ''}>
                      <td>{time(e.occurredAt)}</td><td>{e.eventType}</td><td>{e.state}</td>
                      <td>{short(e.transactionId)}</td><td>{short(e.orderId)}</td><td>{e.sourcePlatform}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </main>
  )
}

function Stat({ label, value, warn }: { label: string; value: number | string; warn?: boolean }) {
  return <div className={`stat${warn ? ' warn' : ''}`}><b>{value}</b><span>{label}</span></div>
}
