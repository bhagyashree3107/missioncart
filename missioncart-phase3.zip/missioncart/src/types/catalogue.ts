export type Category =
  | 'Audio'
  | 'Computing'
  | 'Mobile'
  | 'Wearables'
  | 'Workspace'

export type Product = {
  id: string
  name: string
  description: string
  category: Category
  price: number
  rating: number
  reviewCount: number
  badge?: string
  image: string
  imageAlt: string
  highlights: string[]
}

export type CartItem = {
  product: Product
  quantity: number
}
