export type CheckoutItem = {
  productId: string
  quantity: number
}

export type TransactionEvent = {
  id: string
  transactionId: string
  eventType: string
  occurredAt: string
  state: string
  sourcePlatform: string
  orderId: string | null
  paymentReference: string
  detail?: string | null
}

export type Order = {
  id: string
  status: string
  total: number
  currency: string
  sourcePlatform: string
  paymentReference: string
  createdAt: string
  items: Array<{
    productId: string
    productName: string
    quantity: number
    unitPrice: number
  }>
  events: TransactionEvent[]
}
