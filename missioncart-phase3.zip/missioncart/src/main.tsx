import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import SynesisPage from './synesis/SynesisPage'
import './styles.css'
import './synesis/synesis.css'

// One app, two interfaces: "/" is MissionCart, "/synesis" is the operations page.
const isSynesis = window.location.pathname.replace(/\/+$/, '') === '/synesis'

createRoot(document.getElementById('root')!).render(
  <StrictMode>{isSynesis ? <SynesisPage /> : <App />}</StrictMode>,
)
