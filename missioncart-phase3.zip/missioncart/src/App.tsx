import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { CartDrawer } from './components/CartDrawer'
import { OrderHistory } from './components/OrderHistory'
import { ProductCard } from './components/ProductCard'
import { ProductDetails } from './components/ProductDetails'
import { products as sampleProducts } from './data/products'
import { ApiError, apiClient } from './services/apiClient'
import { catalogueService } from './services/catalogueService'
import { orderService } from './services/orderService'
import type { CartItem, Product } from './types/catalogue'
import type { Order } from './types/orders'

const storageKey = 'missioncart-phase-one-cart'

function getInitialCart(): CartItem[] {
  try {
    const stored = localStorage.getItem(storageKey)
    const parsed: unknown = stored ? JSON.parse(stored) : []
    return Array.isArray(parsed) ? (parsed as CartItem[]) : []
  } catch {
    return []
  }
}

function App() {
  const [catalogue, setCatalogue] = useState<Product[]>(apiClient.baseUrl ? [] : sampleProducts)
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [cart, setCart] = useState<CartItem[]>(getInitialCart)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [notice, setNotice] = useState('')
  const [catalogueError, setCatalogueError] = useState('')
  const [isCatalogueLoading, setIsCatalogueLoading] = useState(Boolean(apiClient.baseUrl))
  const [orders, setOrders] = useState<Order[]>([])
  const [ordersError, setOrdersError] = useState('')
  const [isOrdersLoading, setIsOrdersLoading] = useState(Boolean(apiClient.baseUrl))
  const [isCheckingOut, setIsCheckingOut] = useState(false)
  const [checkoutError, setCheckoutError] = useState('')
  const [checkoutNotice, setCheckoutNotice] = useState('')
  const checkoutAttemptKey = useRef<string | null>(null)

  const apiErrorMessage = (error: unknown, fallback: string) => {
    if (error instanceof ApiError) return error.message
    return fallback
  }

  const loadCatalogue = useCallback(() => {
    if (!apiClient.baseUrl) return Promise.resolve()
    return catalogueService.listProducts()
      .then((incomingProducts) => {
        setCatalogue(incomingProducts)
        setCatalogueError('')
      })
      .catch((error: unknown) => {
        setCatalogue([])
        setCatalogueError(apiErrorMessage(error, 'The catalogue API could not be reached. Check that the backend is running.'))
      })
      .finally(() => {
        setIsCatalogueLoading(false)
      })
  }, [])

  const loadOrders = useCallback(() => {
    if (!apiClient.baseUrl) return Promise.resolve()
    return orderService.listOrders()
      .then((incomingOrders) => {
        setOrders(incomingOrders)
        setOrdersError('')
      })
      .catch((error: unknown) => {
        setOrdersError(apiErrorMessage(error, 'The order API could not be reached. Check that the backend is running.'))
      })
      .finally(() => {
        setIsOrdersLoading(false)
      })
  }, [])

  useEffect(() => {
    void loadCatalogue()
    void loadOrders()
  }, [loadCatalogue, loadOrders])

  useEffect(() => {
    localStorage.setItem(storageKey, JSON.stringify(cart))
  }, [cart])

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(catalogue.map((product) => product.category)))],
    [catalogue],
  )

  const filteredProducts = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase()
    return catalogue.filter((product) => {
      const matchesCategory = activeCategory === 'All' || product.category === activeCategory
      const searchable = `${product.name} ${product.description} ${product.category}`.toLowerCase()
      return matchesCategory && (!normalizedSearch || searchable.includes(normalizedSearch))
    })
  }, [activeCategory, catalogue, search])

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0)
  const subtotal = cart.reduce((total, item) => total + item.product.price * item.quantity, 0)

  const showCatalogue = () => document.getElementById('catalogue')?.scrollIntoView({ behavior: 'smooth' })
  const showOrders = () => document.getElementById('orders')?.scrollIntoView({ behavior: 'smooth' })

  const retryCatalogue = () => {
    setIsCatalogueLoading(true)
    void loadCatalogue()
  }

  const retryOrders = () => {
    setIsOrdersLoading(true)
    void loadOrders()
  }

  const resetCheckoutAttempt = () => {
    checkoutAttemptKey.current = null
    setCheckoutError('')
    setCheckoutNotice('')
  }

  const addToCart = (product: Product) => {
    resetCheckoutAttempt()
    setCart((items) => {
      const currentItem = items.find((item) => item.product.id === product.id)
      if (currentItem) {
        return items.map((item) => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
      }
      return [...items, { product, quantity: 1 }]
    })
    setSelectedProduct(null)
    setNotice(`${product.name} added to your bag.`)
    setIsCartOpen(true)
  }

  const changeQuantity = (productId: string, delta: number) => {
    resetCheckoutAttempt()
    setCart((items) => items.flatMap((item) => {
      if (item.product.id !== productId) return [item]
      const quantity = item.quantity + delta
      return quantity > 0 ? [{ ...item, quantity }] : []
    }))
  }

  const removeFromCart = (productId: string) => {
    resetCheckoutAttempt()
    setCart((items) => items.filter((item) => item.product.id !== productId))
    setNotice('Item removed from your bag.')
  }

  const checkout = async () => {
    if (!apiClient.baseUrl) {
      setCheckoutError('The backend is not configured. Set VITE_API_BASE_URL and try again.')
      return
    }
    if (cart.length === 0 || isCheckingOut) return

    const idempotencyKey = checkoutAttemptKey.current ?? `missioncart-${crypto.randomUUID()}`
    checkoutAttemptKey.current = idempotencyKey
    setCheckoutError('')
    setCheckoutNotice('')
    setIsCheckingOut(true)
    try {
      const order = await orderService.checkout(
        cart.map(({ product, quantity }) => ({ productId: product.id, quantity })),
        idempotencyKey,
      )
      setCart([])
      checkoutAttemptKey.current = null
      setCheckoutNotice(`Order ${order.id} is confirmed and saved to your order history.`)
      setNotice(`Order ${order.id} confirmed.`)
      setOrders((currentOrders) => [order, ...currentOrders.filter((currentOrder) => currentOrder.id !== order.id)])
      void loadOrders()
    } catch (error) {
      setCheckoutError(apiErrorMessage(error, 'Checkout could not be completed. Your bag was not changed; try again.'))
    } finally {
      setIsCheckingOut(false)
    }
  }

  return (
    <div className="app-shell">
      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="MissionCart home">
          <span className="wordmark-mark" aria-hidden="true">M</span>
          <span>Mission<span>Cart</span></span>
        </a>
        <nav className="main-nav" aria-label="Main navigation">
          <button onClick={showCatalogue}>Shop</button>
          <button onClick={showOrders}>Orders</button>
          <a href="#why-missioncart">Why MissionCart</a>
        </nav>
        <button className="bag-button" onClick={() => setIsCartOpen(true)} aria-label={`Open shopping bag with ${cartCount} items`}>
          <span aria-hidden="true">Bag</span>
          <span className="bag-count">{cartCount}</span>
        </button>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-copy">
            <p className="eyebrow hero-eyebrow">Electronics for everyday momentum</p>
            <h1>Find your next <em>favourite</em> thing.</h1>
            <p className="hero-intro">A considered collection of tech that earns its place in your day — selected to sound better, work smarter, and travel lighter.</p>
            <div className="hero-actions">
              <button className="button button-primary" onClick={showCatalogue}>Explore the collection <span aria-hidden="true">↓</span></button>
              <button className="button button-secondary" onClick={() => setSelectedProduct(catalogue[0] ?? null)}>Meet the bestseller</button>
            </div>
            <div className="hero-note"><span aria-hidden="true">✦</span> Twelve useful things. No endless scroll.</div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="hero-orbit orbit-one" />
            <div className="hero-orbit orbit-two" />
            <div className="hero-product hero-phone"><span>Nova</span><i /></div>
            <div className="hero-product hero-headphones">◒</div>
            <div className="hero-product hero-watch"><span>10:09</span></div>
            <div className="hero-visual-label">DESIGNED<br />FOR THE<br />DAY AHEAD</div>
          </div>
        </section>

        <section className="trust-strip" aria-label="MissionCart highlights">
          <p><span aria-hidden="true">◎</span> Thoughtful picks, clearly explained</p>
          <p><span aria-hidden="true">↗</span> Prices in INR — no surprises</p>
          <p><span aria-hidden="true">◌</span> Built for browsing on the go</p>
        </section>

        <section className="catalogue-section" id="catalogue">
          <div className="section-heading">
            <div>
              <p className="eyebrow">The collection</p>
              <h2>Good technology, <em>well chosen.</em></h2>
            </div>
            <p>Start with what makes a visible difference to your everyday.</p>
          </div>

          <div className="catalogue-controls">
            <label className="search-field">
              <span className="sr-only">Search products</span>
              <span aria-hidden="true">⌕</span>
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search the collection" />
              {search && <button onClick={() => setSearch('')} aria-label="Clear search">×</button>}
            </label>
            <div className="category-chips" aria-label="Product categories">
              {categories.map((category) => (
                <button
                  className={activeCategory === category ? 'category-chip active' : 'category-chip'}
                  key={category}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="catalogue-result-row">
            <p><strong>{filteredProducts.length}</strong> {filteredProducts.length === 1 ? 'piece' : 'pieces'} in view</p>
            {activeCategory !== 'All' || search ? <button className="text-button" onClick={() => { setSearch(''); setActiveCategory('All') }}>Reset filters</button> : null}
          </div>

          {catalogueError ? (
            <div className="api-error" role="alert">
              <strong>Catalogue unavailable.</strong>
              <p>{catalogueError}</p>
              <button className="button button-secondary" onClick={retryCatalogue}>Try again</button>
            </div>
          ) : isCatalogueLoading ? (
            <div className="no-results"><p>Loading the MissionCart catalogue…</p></div>
          ) : filteredProducts.length > 0 ? (
            <div className="product-grid">
              {filteredProducts.map((product) => <ProductCard key={product.id} product={product} onAdd={addToCart} onView={setSelectedProduct} />)}
            </div>
          ) : (
            <div className="no-results">
              <span aria-hidden="true">⌕</span>
              <h3>Nothing quite matches that search.</h3>
              <p>Try another term, or return to the full collection.</p>
              <button className="button button-secondary" onClick={() => { setSearch(''); setActiveCategory('All') }}>See all products</button>
            </div>
          )}
        </section>

        <section className="value-section" id="why-missioncart">
          <div className="value-statement">
            <p className="eyebrow">The MissionCart way</p>
            <h2>Less noise.<br /><em>More signal.</em></h2>
            <p>MissionCart is a Phase 2 demo storefront. Catalogue, checkout, orders, and transaction events come from the shared backend; payments remain safely simulated.</p>
          </div>
          <div className="value-cards">
            <article><span>01</span><h3>Easy to explore</h3><p>Search and filters make a compact collection feel even lighter.</p></article>
            <article><span>02</span><h3>Useful detail</h3><p>Every product has its essentials, not a wall of marketing copy.</p></article>
            <article><span>03</span><h3>Orders you can trace</h3><p>Each checkout records a confirmed order and its transaction events.</p></article>
          </div>
        </section>

        <OrderHistory
          configured={Boolean(apiClient.baseUrl)}
          loading={isOrdersLoading}
          orders={orders}
          error={ordersError}
          onRetry={retryOrders}
        />
      </main>

      <footer className="site-footer">
        <a className="wordmark" href="#top"><span className="wordmark-mark" aria-hidden="true">M</span><span>Mission<span>Cart</span></span></a>
        <p>Phase 2 storefront demo · Products, orders, and payments are synthetic.</p>
        <button className="text-button" onClick={showCatalogue}>Back to collection ↑</button>
      </footer>

      <p className="sr-only" aria-live="polite">{notice}</p>
      <ProductDetails product={selectedProduct} onClose={() => setSelectedProduct(null)} onAdd={addToCart} />
      <CartDrawer
        open={isCartOpen}
        items={cart}
        subtotal={subtotal}
        onClose={() => setIsCartOpen(false)}
        onChangeQuantity={changeQuantity}
        onRemove={removeFromCart}
        canCheckout={Boolean(apiClient.baseUrl)}
        isCheckingOut={isCheckingOut}
        checkoutError={checkoutError}
        checkoutNotice={checkoutNotice}
        onCheckout={() => void checkout()}
      />
    </div>
  )
}

export default App
