type ApiOptions = Omit<RequestInit, 'body'> & { body?: unknown }

const configuredBaseUrl = import.meta.env.VITE_API_BASE_URL?.trim()

export class ApiError extends Error {
  constructor(message: string, readonly status: number) {
    super(message)
    this.name = 'ApiError'
  }
}

class ApiClient {
  readonly baseUrl = configuredBaseUrl?.replace(/\/$/, '') ?? ''

  async get<T>(path: string): Promise<T> {
    return this.request<T>(path)
  }

  async post<T>(path: string, options: ApiOptions): Promise<T> {
    return this.request<T>(path, { ...options, method: 'POST' })
  }

  async request<T>(path: string, options: ApiOptions = {}): Promise<T> {
    if (!this.baseUrl) {
      throw new Error('VITE_API_BASE_URL is not configured.')
    }

    const { body, headers, ...requestOptions } = options
    const response = await fetch(`${this.baseUrl}${path}`, {
      ...requestOptions,
      headers: {
        Accept: 'application/json',
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...headers,
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    })

    if (!response.ok) {
      const payload: unknown = await response.json().catch(() => null)
      const message = typeof payload === 'object' && payload !== null && 'detail' in payload && typeof payload.detail === 'string'
        ? payload.detail
        : `The service returned ${response.status}.`
      throw new ApiError(message, response.status)
    }

    return (await response.json()) as T
  }
}

export const apiClient = new ApiClient()
