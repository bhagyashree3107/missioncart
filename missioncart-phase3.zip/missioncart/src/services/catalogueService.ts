import { products } from '../data/products'
import type { Product } from '../types/catalogue'
import { apiClient } from './apiClient'

export const catalogueService = {
  async listProducts(): Promise<Product[]> {
    if (!apiClient.baseUrl) {
      return products
    }

    return apiClient.get<Product[]>('/api/catalogue/products')
  },
}
