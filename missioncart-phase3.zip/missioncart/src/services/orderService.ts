import { apiClient } from './apiClient'
import type { CheckoutItem, Order } from '../types/orders'

export const orderService = {
  checkout(items: CheckoutItem[], idempotencyKey: string): Promise<Order> {
    return apiClient.post<Order>('/api/orders', {
      body: { items },
      headers: { 'Idempotency-Key': idempotencyKey },
    })
  },

  listOrders(): Promise<Order[]> {
    return apiClient.get<Order[]>('/api/orders')
  },
}
