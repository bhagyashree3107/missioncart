import type { CartItem } from '../types/catalogue'
import { formatPrice } from '../lib/format'
import { ProductImage } from './ProductImage'

type CartDrawerProps = {
  open: boolean
  items: CartItem[]
  subtotal: number
  onClose: () => void
  onChangeQuantity: (productId: string, delta: number) => void
  onRemove: (productId: string) => void
  canCheckout: boolean
  isCheckingOut: boolean
  checkoutError: string
  checkoutNotice: string
  onCheckout: () => void
}

export function CartDrawer({
  open,
  items,
  subtotal,
  onClose,
  onChangeQuantity,
  onRemove,
  canCheckout,
  isCheckingOut,
  checkoutError,
  checkoutNotice,
  onCheckout,
}: CartDrawerProps) {
  if (!open) return null

  return (
    <div className="cart-layer" role="presentation" onMouseDown={onClose}>
      <aside className="cart-drawer" aria-label="Shopping bag" onMouseDown={(event) => event.stopPropagation()}>
        <div className="cart-header">
          <div>
            <p className="eyebrow">Your selection</p>
            <h2>Shopping bag</h2>
          </div>
          <button className="close-button" onClick={onClose} aria-label="Close shopping bag">×</button>
        </div>

        {items.length === 0 ? (
          <div className="empty-bag">
            <span aria-hidden="true">◌</span>
            <h3>Your bag is ready when you are.</h3>
            <p>Choose something useful, beautiful, or both.</p>
            <button className="button button-secondary" onClick={onClose}>Continue browsing</button>
          </div>
        ) : (
          <>
            <div className="cart-items">
              {items.map(({ product, quantity }) => (
                <div className="cart-item" key={product.id}>
                  <ProductImage className="cart-image" src={product.image} alt={product.imageAlt} label={product.name} />
                  <div className="cart-item-copy">
                    <h3>{product.name}</h3>
                    <p>{formatPrice(product.price)}</p>
                    <div className="quantity-row">
                      <div className="quantity-control" aria-label={`Quantity for ${product.name}`}>
                        <button onClick={() => onChangeQuantity(product.id, -1)} aria-label={`Decrease ${product.name} quantity`}>−</button>
                        <span>{quantity}</span>
                        <button onClick={() => onChangeQuantity(product.id, 1)} aria-label={`Increase ${product.name} quantity`}>+</button>
                      </div>
                      <button className="remove-button" onClick={() => onRemove(product.id)}>Remove</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="cart-summary">
              <div><span>Subtotal</span><strong>{formatPrice(subtotal)}</strong></div>
              <p>Phase 2 checkout is simulated: no real payment is collected.</p>
              {checkoutError && <p className="checkout-message checkout-error" role="alert">{checkoutError}</p>}
              {checkoutNotice && <p className="checkout-message checkout-success" role="status">{checkoutNotice}</p>}
              <button className="button button-primary checkout-button" onClick={onCheckout} disabled={!canCheckout || isCheckingOut}>
                {isCheckingOut ? 'Confirming order…' : canCheckout ? 'Place simulated order' : 'Configure backend to check out'}
              </button>
            </div>
          </>
        )}
      </aside>
    </div>
  )
}
