import type { Product } from '../types/catalogue'
import { formatPrice } from '../lib/format'
import { ProductImage } from './ProductImage'

type ProductCardProps = {
  product: Product
  onAdd: (product: Product) => void
  onView: (product: Product) => void
}

export function ProductCard({ product, onAdd, onView }: ProductCardProps) {
  return (
    <article className="product-card">
      <button className="product-image-button" onClick={() => onView(product)} aria-label={`View ${product.name}`}>
        <ProductImage className="product-image" src={product.image} alt={product.imageAlt} label={product.name} />
        {product.badge && <span className="product-badge">{product.badge}</span>}
      </button>
      <div className="product-copy">
        <p className="eyebrow">{product.category}</p>
        <h3>{product.name}</h3>
        <p className="product-description">{product.description}</p>
        <div className="rating" aria-label={`${product.rating} out of 5 stars from ${product.reviewCount} reviews`}>
          <span aria-hidden="true">★</span> {product.rating} <small>({product.reviewCount})</small>
        </div>
        <div className="product-bottom">
          <strong>{formatPrice(product.price)}</strong>
          <div className="product-actions">
            <button className="text-button" onClick={() => onView(product)}>Details</button>
            <button className="icon-add" onClick={() => onAdd(product)} aria-label={`Add ${product.name} to cart`}>+</button>
          </div>
        </div>
      </div>
    </article>
  )
}
