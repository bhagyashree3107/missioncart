import { formatOrderDate, formatPrice } from '../lib/format'
import type { Order } from '../types/orders'

type OrderHistoryProps = {
  configured: boolean
  loading: boolean
  orders: Order[]
  error: string
  onRetry: () => void
}

export function OrderHistory({ configured, loading, orders, error, onRetry }: OrderHistoryProps) {
  return (
    <section className="orders-section" id="orders">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Order history</p>
          <h2>Your MissionCart <em>orders.</em></h2>
        </div>
        <p>Orders shown here are loaded from the shared transaction backend.</p>
      </div>

      {!configured ? (
        <div className="orders-empty">
          <h3>Connect the backend to view orders.</h3>
          <p>Set <code>VITE_API_BASE_URL</code> before starting the storefront.</p>
        </div>
      ) : loading ? (
        <div className="orders-empty"><p>Loading your order history…</p></div>
      ) : error ? (
        <div className="api-error" role="alert">
          <strong>Order history is unavailable.</strong>
          <p>{error}</p>
          <button className="button button-secondary" onClick={onRetry}>Try again</button>
        </div>
      ) : orders.length === 0 ? (
        <div className="orders-empty"><h3>No orders yet.</h3><p>Complete checkout and your confirmed order will appear here.</p></div>
      ) : (
        <div className="order-list">
          {orders.map((order) => (
            <article className="order-card" key={order.id}>
              <div className="order-card-header">
                <div>
                  <p className="eyebrow">{order.status}</p>
                  <h3>{order.id}</h3>
                  <p>{formatOrderDate(order.createdAt)}</p>
                </div>
                <strong>{formatPrice(order.total)}</strong>
              </div>
              <ul>
                {order.items.map((item) => <li key={item.productId}>{item.quantity} × {item.productName}</li>)}
              </ul>
              <p className="order-event-count">{order.events.length} recorded transaction events</p>
            </article>
          ))}
        </div>
      )}
    </section>
  )
}
