import { useState } from 'react'

type ProductImageProps = {
  src: string
  alt: string
  label: string
  className?: string
}

export function ProductImage({ src, alt, label, className = '' }: ProductImageProps) {
  const [failed, setFailed] = useState(false)

  if (failed) {
    return (
      <div className={`image-fallback ${className}`} role="img" aria-label={`${label} image unavailable`}>
        <span aria-hidden="true">✦</span>
        <small>MissionCart</small>
        <strong>{label}</strong>
      </div>
    )
  }

  return <img className={className} src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} />
}
