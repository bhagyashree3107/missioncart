import type { Product } from '../types/catalogue'
import { formatPrice } from '../lib/format'
import { ProductImage } from './ProductImage'

type ProductDetailsProps = {
  product: Product | null
  onClose: () => void
  onAdd: (product: Product) => void
}

export function ProductDetails({ product, onClose, onAdd }: ProductDetailsProps) {
  if (!product) return null

  return (
    <div className="dialog-layer" role="presentation" onMouseDown={onClose}>
      <section
        className="product-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="product-dialog-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <button className="close-button" onClick={onClose} aria-label="Close product details">×</button>
        <div className="dialog-image-wrap">
          <ProductImage className="dialog-image" src={product.image} alt={product.imageAlt} label={product.name} />
        </div>
        <div className="dialog-copy">
          <p className="eyebrow">{product.category}</p>
          <h2 id="product-dialog-title">{product.name}</h2>
          <p className="dialog-description">{product.description}</p>
          <p className="dialog-price">{formatPrice(product.price)}</p>
          <p className="rating"><span aria-hidden="true">★</span> {product.rating} <small>({product.reviewCount} verified ratings)</small></p>
          <ul className="highlights">
            {product.highlights.map((highlight) => <li key={highlight}>{highlight}</li>)}
          </ul>
          <button className="button button-primary dialog-add" onClick={() => onAdd(product)}>
            Add to bag <span aria-hidden="true">→</span>
          </button>
        </div>
      </section>
    </div>
  )
}
