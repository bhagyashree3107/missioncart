# MissionCart + SYNESIS

MissionCart is a synthetic electronics storefront. SYNESIS is a monitoring page for the same system that detects when a payment succeeded but no order was created, shows the evidence, and can safely create the missing order. Everything runs on one machine: one FastAPI backend, one SQLite database, one Vite frontend.

- MissionCart: `http://127.0.0.1:5173/`
- SYNESIS operations: `http://127.0.0.1:5173/synesis`

All data is synthetic and local. No real payment is collected. See BUILD_STATUS.md for what has and has not been verified.

## What is included

- A responsive React/Vite storefront in `src/`.
- FastAPI application in `backend/app.py`.
- SQLite repository and schema in `backend/database.py`.
- Synthetic seeded catalogue in `backend/catalogue.py`.
- SYNESIS monitor in `backend/synesis.py` and operations page in `src/synesis/`.
- Sixteen backend tests in `backend/tests/`.
- Synthetic, local-only orders and simulated payment references. No real payment is collected.

## Run locally on macOS

Use two terminals from the repository root.

In the first terminal, create the Python environment, install the backend dependencies, run the tests, and start the API:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r backend/requirements.txt
python -m unittest discover -s backend/tests -v
SYNESIS_ENABLE_FAULT_INJECTION=true python -m uvicorn backend.app:app --host 127.0.0.1 --port 8001
```

The `SYNESIS_ENABLE_FAULT_INJECTION=true` prefix only makes the fault switch available; the switch itself starts OFF. Leave the prefix out for normal operation. Setting `SYNESIS_ENV=production` blocks fault injection even if the variable is set.

In the second terminal, install the frontend dependencies, point the app at the API, verify it, and start Vite:

```sh
npm ci
cp .env.example .env
npm run lint
npm run build
VITE_API_BASE_URL=http://127.0.0.1:8001 npm run dev -- --host 127.0.0.1 --port 5173
```

Open `http://127.0.0.1:5173` in a browser.

The frontend reads `VITE_API_BASE_URL` from `.env`; `.env.example` has the matching local API origin. The API accepts the normal Vite origins on `localhost` and `127.0.0.1` for ports 5173 and 5174. To allow a different frontend origin, set `MISSIONCART_CORS_ORIGINS` before starting Uvicorn, as a comma-separated list.

## Verify the live API

With the API running, these macOS commands check the main Phase 2 endpoints:

```sh
curl --fail --silent --show-error http://127.0.0.1:8001/health
curl --fail --silent --show-error http://127.0.0.1:8001/api/catalogue/products
curl --include --request POST http://127.0.0.1:8001/api/orders \
  --header 'Content-Type: application/json' \
  --header 'Idempotency-Key: missioncart-manual-checkout-001' \
  --data '{"items":[{"productId":"orbit-anc-headphones","quantity":1}]}'
```

Copy the returned order ID and use it to retrieve the persisted order and events:

```sh
curl --fail --silent --show-error http://127.0.0.1:8001/api/orders/REPLACE_WITH_ORDER_ID
curl --fail --silent --show-error http://127.0.0.1:8001/api/orders/REPLACE_WITH_ORDER_ID/events
```

Repeat the same `POST` command with the same key and same items to confirm duplicate-submission protection: the response is `200 OK` and returns the existing order. Reusing that key with different items returns `409 Conflict`.

## Data and limits

`backend/missioncart.sqlite3` is created at runtime and ignored by Git. It contains only local synthetic data. Delete that file only when you intentionally want to reset local orders and transaction events.

This is a local demo, not a production payment system. It has no authentication, delivery/tax integration, real payment provider, production deployment configuration, or Phase 3+ SYNESIS features.

## Demo: failure, detection, recovery

1. Open `http://127.0.0.1:5173/synesis` in one browser tab and `http://127.0.0.1:5173/` in another.
2. On `/synesis`, press **Turn on** under Fault injection.
3. In MissionCart, add a product and press **Place simulated order**. The page says the payment was recorded, the order could not be created, and a retry will not charge again.
4. Back on `/synesis`, within about 4 seconds a `PAID_NO_ORDER` incident appears. Select it to see the evidence, probable cause and timeline.
5. Press **Recover** while the fault is still on: it reports FAILED and the incident stays open.
6. Press **Turn off**, then **Recover** again: it creates the order only, verifies the database, and resolves the incident. The Orders history in MissionCart now shows the order.

## SYNESIS API

`GET /api/synesis/overview`, `POST /api/synesis/scan`, `GET /api/synesis/incidents/{id}`, `POST /api/synesis/incidents/{id}/recover`, `GET|POST /api/synesis/fault-injection`. There is no authentication; keep it on `127.0.0.1`.

Backend settings: `SYNESIS_ENABLE_FAULT_INJECTION`, `SYNESIS_ENV`, `SYNESIS_SCAN_GRACE_SECONDS` (default 30), `MISSIONCART_DB_PATH`.
