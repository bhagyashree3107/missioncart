from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from backend.database import (
    IdempotencyConflictError,
    MissionCartDatabase,
    UnknownProductError,
)


class MissionCartDatabaseTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.database = MissionCartDatabase(Path(self.temporary_directory.name) / "missioncart.sqlite3")

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def test_health_reports_sqlite_ready(self) -> None:
        self.assertEqual(self.database.health(), {"status": "ok", "database": "ok"})

    def test_seeded_catalogue_has_the_twelve_storefront_products(self) -> None:
        products = self.database.list_products()
        self.assertEqual(len(products), 12)
        self.assertEqual(products[0]["id"], "orbit-anc-headphones")

    def test_checkout_persists_the_calculated_order(self) -> None:
        order, reused = self.database.create_order(
            [("orbit-anc-headphones", 2), ("beam-desk-lamp", 1)], "checkout-one"
        )
        self.assertFalse(reused)
        self.assertEqual(order["status"], "CONFIRMED")
        self.assertEqual(order["total"], 14897)
        self.assertEqual(len(order["items"]), 2)

    def test_order_can_be_retrieved_after_checkout(self) -> None:
        order, _ = self.database.create_order([("nova-one-phone", 1)], "checkout-two")
        fetched = self.database.get_order(order["id"])
        self.assertEqual(fetched["id"], order["id"])
        self.assertEqual(fetched["items"][0]["productName"], "Nova One Phone")

    def test_checkout_persists_canonical_transaction_events(self) -> None:
        order, _ = self.database.create_order([("vector-smart-watch", 1)], "checkout-three")
        events = self.database.list_events(order["id"])
        self.assertEqual([event["eventType"] for event in events], ["CHECKOUT_ACCEPTED", "PAYMENT_CAPTURED", "ORDER_CONFIRMED"])
        self.assertTrue(all(event["transactionId"].startswith("txn_") for event in events))
        self.assertTrue(all(event["orderId"] == order["id"] for event in events))

    def test_repeated_checkout_with_same_key_reuses_order_without_new_events(self) -> None:
        first, first_reused = self.database.create_order([("frame-27-monitor", 1)], "retry-key")
        second, second_reused = self.database.create_order([("frame-27-monitor", 1)], "retry-key")
        self.assertFalse(first_reused)
        self.assertTrue(second_reused)
        self.assertEqual(first["id"], second["id"])
        self.assertEqual(len(self.database.list_events(first["id"])), 3)

    def test_invalid_checkouts_do_not_create_an_order(self) -> None:
        with self.assertRaises(UnknownProductError):
            self.database.create_order([("not-a-product", 1)], "unknown-product")
        self.database.create_order([("beam-desk-lamp", 1)], "fixed-key")
        with self.assertRaises(IdempotencyConflictError):
            self.database.create_order([("beam-desk-lamp", 2)], "fixed-key")
        self.assertEqual(len(self.database.list_orders()), 1)


if __name__ == "__main__":
    unittest.main()
