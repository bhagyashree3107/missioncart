from __future__ import annotations

import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

from backend.app import create_app

ITEMS = {"items": [{"productId": "orbit-anc-headphones", "quantity": 1}, {"productId": "beam-desk-lamp", "quantity": 2}]}


class SynesisApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp.name) / "t.sqlite3"
        self.env = patch.dict(os.environ, {"SYNESIS_ENABLE_FAULT_INJECTION": "true", "SYNESIS_ENV": "development"})
        self.env.start()
        self.client = TestClient(create_app(self.db_path, grace_seconds=0))

    def tearDown(self) -> None:
        self.client.close()
        self.env.stop()
        self.tmp.cleanup()

    def q(self, sql: str, *args):
        with sqlite3.connect(self.db_path) as c:
            return c.execute(sql, args).fetchall()

    def checkout(self, key: str):
        return self.client.post("/api/orders", json=ITEMS, headers={"Idempotency-Key": key})

    def inject_failure(self, key: str = "fault-1") -> str:
        self.client.post("/api/synesis/fault-injection", json={"enabled": True})
        self.assertEqual(self.checkout(key).status_code, 503)
        self.client.post("/api/synesis/scan")
        return self.client.get("/api/synesis/overview").json()["incidents"][0]["id"]

    # --- normal flow ---
    def test_successful_checkout_persists_payment_order_and_events(self):
        r = self.checkout("ok-1")
        self.assertEqual(r.status_code, 201)
        self.assertEqual([e["eventType"] for e in r.json()["events"]], ["CHECKOUT_ACCEPTED", "PAYMENT_CAPTURED", "ORDER_CONFIRMED"])
        self.assertEqual(self.q("SELECT status FROM payments")[0][0], "SUCCESS")
        self.assertEqual(self.client.post("/api/synesis/scan").json(), {"created": [], "resolved": []})
        ov = self.client.get("/api/synesis/overview").json()
        self.assertEqual(ov["transactions"][0]["consistency"], "CONSISTENT")
        self.assertEqual(ov["counts"]["openIncidents"], 0)

    # --- fault injection ---
    def test_fault_injection_is_off_by_default_and_blocked_in_production(self):
        self.assertFalse(self.client.get("/api/synesis/fault-injection").json()["enabled"])
        self.assertEqual(self.checkout("default-off").status_code, 201)
        with patch.dict(os.environ, {"SYNESIS_ENV": "production"}):
            self.assertEqual(self.client.post("/api/synesis/fault-injection", json={"enabled": True}).status_code, 403)
            self.assertFalse(self.client.get("/api/synesis/fault-injection").json()["available"])
        with patch.dict(os.environ, {"SYNESIS_ENABLE_FAULT_INJECTION": ""}):
            self.assertEqual(self.client.post("/api/synesis/fault-injection", json={"enabled": True}).status_code, 403)

    def test_fault_leaves_payment_without_order_and_creates_incident(self):
        inc_id = self.inject_failure()
        self.assertEqual(self.q("SELECT status FROM payments")[0][0], "SUCCESS")
        self.assertEqual(self.q("SELECT COUNT(*) FROM orders")[0][0], 0)
        detail = self.client.get(f"/api/synesis/incidents/{inc_id}").json()
        self.assertEqual(detail["incident"]["type"], "PAID_NO_ORDER")
        self.assertEqual(detail["incident"]["status"], "OPEN")
        self.assertIn("ORDER_CREATION_FAILED", [e["eventType"] for e in detail["timeline"]])
        self.assertTrue(any("no order row" in f.lower() for f in detail["incident"]["evidence"]))

    def test_repeated_scans_do_not_duplicate_open_incidents(self):
        self.inject_failure()
        for _ in range(3):
            self.assertEqual(self.client.post("/api/synesis/scan").json()["created"], [])
        self.assertEqual(self.q("SELECT COUNT(*) FROM incidents")[0][0], 1)

    def test_customer_retry_with_same_key_never_charges_twice(self):
        self.inject_failure("retry-key")
        self.client.post("/api/synesis/fault-injection", json={"enabled": False})
        self.assertEqual(self.checkout("retry-key").status_code, 201)
        self.assertEqual(self.q("SELECT COUNT(*) FROM payments")[0][0], 1)
        self.assertEqual(self.q("SELECT COUNT(*) FROM orders")[0][0], 1)

    # --- recovery ---
    def test_recovery_creates_order_only_and_verifies_final_state(self):
        inc_id = self.inject_failure()
        self.client.post("/api/synesis/fault-injection", json={"enabled": False})
        r = self.client.post(f"/api/synesis/incidents/{inc_id}/recover").json()
        self.assertEqual(r["outcome"], "SUCCEEDED")
        self.assertEqual(r["incident"]["status"], "RESOLVED")
        self.assertEqual(self.q("SELECT COUNT(*) FROM payments")[0][0], 1)
        self.assertEqual(self.q("SELECT COUNT(*) FROM orders")[0][0], 1)
        self.assertEqual(self.q("SELECT total FROM orders")[0][0], self.q("SELECT amount FROM payments")[0][0])
        self.assertEqual(self.q("SELECT verified FROM recovery_attempts")[0][0], 1)
        self.assertEqual(self.q("SELECT COUNT(*) FROM transaction_events WHERE order_id IS NULL")[0][0], 0)
        # recovering again is rejected and creates nothing
        self.assertEqual(self.client.post(f"/api/synesis/incidents/{inc_id}/recover").status_code, 409)
        self.assertEqual(self.q("SELECT COUNT(*) FROM orders")[0][0], 1)

    def test_recovery_is_not_resolved_while_fault_still_active(self):
        inc_id = self.inject_failure()
        r = self.client.post(f"/api/synesis/incidents/{inc_id}/recover").json()
        self.assertEqual(r["outcome"], "FAILED")
        self.assertEqual(r["incident"]["status"], "OPEN")
        self.assertEqual(self.q("SELECT COUNT(*) FROM orders")[0][0], 0)

    def test_recovery_blocked_unless_payment_is_success(self):
        for status in ("UNKNOWN", "PENDING", "FAILED"):
            with self.subTest(status=status):
                inc_id = self.inject_failure(f"blocked-{status}")
                with sqlite3.connect(self.db_path) as c:
                    c.execute("UPDATE payments SET status=? WHERE idempotency_key=?", (status, f"blocked-{status}"))
                self.client.post("/api/synesis/fault-injection", json={"enabled": False})
                r = self.client.post(f"/api/synesis/incidents/{inc_id}/recover").json()
                self.assertEqual(r["outcome"], "BLOCKED")
                self.assertEqual(r["incident"]["status"], "OPEN")
                self.assertEqual(self.q("SELECT COUNT(*) FROM orders")[0][0], 0)

    def test_uncertain_payment_raises_incident_but_failed_payment_does_not(self):
        self.inject_failure("u-1")
        with sqlite3.connect(self.db_path) as c:
            c.execute("UPDATE incidents SET status='RESOLVED'")
            c.execute("UPDATE payments SET status='UNKNOWN'")
        self.assertEqual(len(self.client.post("/api/synesis/scan").json()["created"]), 1)
        self.assertEqual(self.q("SELECT incident_type FROM incidents WHERE status='OPEN'")[0][0], "PAYMENT_STATE_UNCERTAIN")
        with sqlite3.connect(self.db_path) as c:
            c.execute("UPDATE incidents SET status='RESOLVED'")
            c.execute("UPDATE payments SET status='FAILED'")
        self.assertEqual(self.client.post("/api/synesis/scan").json()["created"], [])


if __name__ == "__main__":
    unittest.main()
