"""FastAPI application for the MissionCart Phase 2 transaction backend."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, Header, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .database import (
    IdempotencyConflictError,
    MissionCartDatabase,
    OrderCreationFailedError,
    OrderNotFoundError,
    UnknownProductError,
)
from .synesis import (
    FaultInjection,
    FaultInjectionUnavailableError,
    IncidentNotFoundError,
    IncidentNotOpenError,
    SynesisMonitor,
)


class CheckoutItem(BaseModel):
    productId: str = Field(min_length=1, max_length=120)
    quantity: int = Field(ge=1, le=20)


class CheckoutRequest(BaseModel):
    items: list[CheckoutItem] = Field(min_length=1, max_length=20)


class FaultToggle(BaseModel):
    enabled: bool


def _default_database_path() -> Path:
    return Path(os.getenv("MISSIONCART_DB_PATH", "backend/missioncart.sqlite3"))


def _cors_origins() -> list[str]:
    configured = os.getenv(
        "MISSIONCART_CORS_ORIGINS",
        "http://localhost:5173,http://127.0.0.1:5173,http://localhost:5174,http://127.0.0.1:5174",
    )
    return [origin.strip() for origin in configured.split(",") if origin.strip()]


def create_app(database_path: str | Path | None = None, grace_seconds: float | None = None) -> FastAPI:
    database = MissionCartDatabase(database_path or _default_database_path())
    app = FastAPI(title="MissionCart API", version="0.3.0")
    app.state.database = database
    faults = FaultInjection()
    monitor = SynesisMonitor(database, grace_seconds)
    app.state.faults = faults
    app.state.monitor = monitor
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins(),
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type", "Idempotency-Key"],
    )

    @app.get("/health")
    def health() -> dict[str, str]:
        return database.health()

    @app.get("/api/catalogue/products")
    def list_products() -> list[dict[str, object]]:
        return database.list_products()

    @app.post("/api/orders", status_code=201)
    def checkout(
        checkout_request: CheckoutRequest,
        response: Response,
        idempotency_key: Annotated[str | None, Header(alias="Idempotency-Key")] = None,
    ) -> dict[str, object]:
        if idempotency_key is None or not idempotency_key.strip():
            raise HTTPException(status_code=400, detail="An Idempotency-Key header is required.")
        try:
            order, reused = database.create_order(
                [(item.productId, item.quantity) for item in checkout_request.items],
                idempotency_key,
                fail_after_payment=faults.active(),
            )
        except OrderCreationFailedError as error:
            raise HTTPException(
                status_code=503,
                detail=(
                    "Your payment was recorded but we could not create the order. "
                    "Retrying will not charge you again. "
                    f"Reference: {error.payment_reference}"
                ),
            ) from error
        except UnknownProductError as error:
            raise HTTPException(status_code=422, detail=f"Unknown product: {error}") from error
        except IdempotencyConflictError as error:
            raise HTTPException(status_code=409, detail=str(error)) from error
        except ValueError as error:
            raise HTTPException(status_code=400, detail=str(error)) from error
        if reused:
            response.status_code = 200
        return order

    @app.get("/api/orders")
    def list_orders() -> list[dict[str, object]]:
        return database.list_orders()

    @app.get("/api/orders/{order_id}")
    def get_order(order_id: str) -> dict[str, object]:
        try:
            return database.get_order(order_id)
        except OrderNotFoundError as error:
            raise HTTPException(status_code=404, detail="Order not found.") from error

    @app.get("/api/orders/{order_id}/events")
    def get_order_events(order_id: str) -> list[dict[str, str]]:
        try:
            return database.list_events(order_id)
        except OrderNotFoundError as error:
            raise HTTPException(status_code=404, detail="Order not found.") from error

    # ---- SYNESIS operations API (same app, same database) ----

    @app.get("/api/synesis/overview")
    def synesis_overview() -> dict[str, object]:
        return {**monitor.overview(), "faultInjection": faults.status()}

    @app.post("/api/synesis/scan")
    def synesis_scan() -> dict[str, list[str]]:
        return monitor.scan()

    @app.get("/api/synesis/incidents/{incident_id}")
    def synesis_incident(incident_id: str) -> dict[str, object]:
        try:
            return monitor.incident_detail(incident_id)
        except IncidentNotFoundError as error:
            raise HTTPException(status_code=404, detail="Incident not found.") from error

    @app.post("/api/synesis/incidents/{incident_id}/recover")
    def synesis_recover(incident_id: str) -> dict[str, object]:
        try:
            return monitor.recover(incident_id, fault_active=faults.active())
        except IncidentNotFoundError as error:
            raise HTTPException(status_code=404, detail="Incident not found.") from error
        except IncidentNotOpenError as error:
            raise HTTPException(status_code=409, detail=str(error)) from error

    @app.get("/api/synesis/fault-injection")
    def fault_status() -> dict[str, object]:
        return faults.status()

    @app.post("/api/synesis/fault-injection")
    def fault_set(toggle: FaultToggle) -> dict[str, object]:
        try:
            return faults.set(toggle.enabled)
        except FaultInjectionUnavailableError as error:
            raise HTTPException(status_code=403, detail=str(error)) from error

    return app


app = create_app()
