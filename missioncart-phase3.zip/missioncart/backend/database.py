"""SQLite persistence for the Phase 2 MissionCart API."""

from __future__ import annotations

from collections import defaultdict
from contextlib import contextmanager
from datetime import UTC, datetime
import json
from pathlib import Path
import sqlite3
from typing import Iterable, Iterator
from uuid import uuid4

from .catalogue import CATALOGUE


class UnknownProductError(ValueError):
    """Raised when a checkout references a product outside the catalogue."""


class IdempotencyConflictError(ValueError):
    """Raised when an idempotency key is reused with different items."""


class OrderNotFoundError(LookupError):
    """Raised when an order identifier does not exist."""


class OrderCreationFailedError(RuntimeError):
    """Raised when order creation fails after the simulated payment was captured."""

    def __init__(self, transaction_id: str, payment_reference: str, message: str):
        super().__init__(message)
        self.transaction_id = transaction_id
        self.payment_reference = payment_reference


EVENTS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS transaction_events (
    id TEXT PRIMARY KEY,
    transaction_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    position INTEGER NOT NULL,
    occurred_at TEXT NOT NULL,
    state TEXT NOT NULL,
    source_platform TEXT NOT NULL,
    order_id TEXT REFERENCES orders(id),
    payment_reference TEXT NOT NULL,
    detail TEXT
)
"""


class MissionCartDatabase:
    def __init__(self, database_path: str | Path):
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _migrate_events_table(connection: sqlite3.Connection) -> None:
        """Phase 3: order_id becomes nullable and a detail column is added (older DBs only)."""
        columns = {row["name"]: row for row in connection.execute("PRAGMA table_info(transaction_events)")}
        if not columns or (not columns["order_id"]["notnull"] and "detail" in columns):
            return
        position = (
            "position" if "position" in columns
            else "CASE event_type WHEN 'CHECKOUT_ACCEPTED' THEN 1 WHEN 'ORDER_CONFIRMED' THEN 2 ELSE 0 END"
        )
        connection.execute("DROP INDEX IF EXISTS transaction_events_order_id_idx")
        connection.execute("ALTER TABLE transaction_events RENAME TO transaction_events_old")
        connection.execute(EVENTS_TABLE_SQL)
        connection.execute(
            f"""INSERT INTO transaction_events (id, transaction_id, event_type, position, occurred_at,
                state, source_platform, order_id, payment_reference)
                SELECT id, transaction_id, event_type, {position}, occurred_at, state, source_platform,
                order_id, payment_reference FROM transaction_events_old"""
        )
        connection.execute("DROP TABLE transaction_events_old")

    def initialize(self) -> None:
        with self._connection() as connection:
            self._migrate_events_table(connection)
            connection.execute(EVENTS_TABLE_SQL)
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS products (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT NOT NULL,
                    category TEXT NOT NULL,
                    price INTEGER NOT NULL CHECK(price >= 0),
                    rating REAL NOT NULL,
                    review_count INTEGER NOT NULL,
                    badge TEXT,
                    image TEXT NOT NULL,
                    image_alt TEXT NOT NULL,
                    highlights_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS orders (
                    id TEXT PRIMARY KEY,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    status TEXT NOT NULL,
                    total INTEGER NOT NULL CHECK(total >= 0),
                    currency TEXT NOT NULL,
                    source_platform TEXT NOT NULL,
                    payment_reference TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS order_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    order_id TEXT NOT NULL REFERENCES orders(id),
                    product_id TEXT NOT NULL REFERENCES products(id),
                    product_name TEXT NOT NULL,
                    quantity INTEGER NOT NULL CHECK(quantity > 0),
                    unit_price INTEGER NOT NULL CHECK(unit_price >= 0)
                );
                CREATE TABLE IF NOT EXISTS payments (
                    payment_reference TEXT PRIMARY KEY,
                    transaction_id TEXT NOT NULL UNIQUE,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    amount INTEGER NOT NULL CHECK(amount >= 0),
                    currency TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('SUCCESS','FAILED','PENDING','UNKNOWN')),
                    items_json TEXT NOT NULL,
                    source_platform TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS incidents (
                    id TEXT PRIMARY KEY,
                    transaction_id TEXT NOT NULL,
                    payment_reference TEXT NOT NULL,
                    incident_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN ('OPEN','RESOLVED')),
                    summary TEXT NOT NULL,
                    probable_cause TEXT NOT NULL,
                    evidence_json TEXT NOT NULL,
                    detected_at TEXT NOT NULL,
                    resolved_at TEXT,
                    resolution TEXT
                );
                CREATE UNIQUE INDEX IF NOT EXISTS incidents_one_open_per_txn
                    ON incidents(transaction_id, incident_type) WHERE status = 'OPEN';
                CREATE TABLE IF NOT EXISTS recovery_attempts (
                    id TEXT PRIMARY KEY,
                    incident_id TEXT NOT NULL REFERENCES incidents(id),
                    attempted_at TEXT NOT NULL,
                    outcome TEXT NOT NULL CHECK(outcome IN ('SUCCEEDED','BLOCKED','FAILED')),
                    reason TEXT NOT NULL,
                    order_id TEXT,
                    verified INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS transaction_events_order_id_idx
                    ON transaction_events(order_id, occurred_at);
                """
            )
            event_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(transaction_events)").fetchall()
            }
            if "position" not in event_columns:
                connection.execute(
                    "ALTER TABLE transaction_events ADD COLUMN position INTEGER NOT NULL DEFAULT 0"
                )
                connection.execute(
                    """
                    UPDATE transaction_events
                    SET position = CASE event_type
                        WHEN 'CHECKOUT_ACCEPTED' THEN 1
                        WHEN 'ORDER_CONFIRMED' THEN 2
                        ELSE 0
                    END
                    """
                )
            connection.executemany(
                """
                INSERT OR IGNORE INTO products (
                    id, name, description, category, price, rating, review_count,
                    badge, image, image_alt, highlights_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    (
                        product["id"], product["name"], product["description"], product["category"],
                        product["price"], product["rating"], product["reviewCount"], product.get("badge"),
                        product["image"], product["imageAlt"], json.dumps(product["highlights"]),
                    )
                    for product in CATALOGUE
                ],
            )

            connection.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS orders_payment_reference_uq ON orders(payment_reference)"
            )
            # Orders created before Phase 3 have no payments row; derive one from the order itself.
            connection.execute(
                """
                INSERT OR IGNORE INTO payments (payment_reference, transaction_id, idempotency_key, amount,
                    currency, status, items_json, source_platform, created_at)
                SELECT o.payment_reference,
                       COALESCE((SELECT e.transaction_id FROM transaction_events e WHERE e.order_id = o.id LIMIT 1),
                                'txn_legacy_' || o.id),
                       o.idempotency_key, o.total, o.currency, 'SUCCESS', '[]', o.source_platform, o.created_at
                FROM orders o
                """
            )

    def health(self) -> dict[str, str]:
        with self._connection() as connection:
            connection.execute("SELECT 1").fetchone()
        return {"status": "ok", "database": "ok"}

    def list_products(self) -> list[dict[str, object]]:
        with self._connection() as connection:
            rows = connection.execute("SELECT * FROM products ORDER BY rowid").fetchall()
        return [self._product_from_row(row) for row in rows]

    def create_order(
        self, items: Iterable[tuple[str, int]], idempotency_key: str, fail_after_payment: bool = False
    ) -> tuple[dict[str, object], bool]:
        """Capture the simulated payment, then create the order.

        Payment and order are separate transactions on purpose: this is the window in which a
        real checkout can fail. `fail_after_payment` is the development-only fault injection.
        """
        normalized_items = self._normalize_items(items)
        if not idempotency_key.strip():
            raise ValueError("An Idempotency-Key header is required.")

        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT id FROM orders WHERE idempotency_key = ?", (idempotency_key,)
            ).fetchone()
            if existing:
                self._assert_same_items(connection, existing["id"], normalized_items)
                result = self._order_from_connection(connection, existing["id"])
                connection.commit()
                return result, True

            payment = connection.execute(
                "SELECT * FROM payments WHERE idempotency_key = ?", (idempotency_key,)
            ).fetchone()
            if payment:
                # Retry after a failed order creation: reuse the captured payment, never charge again.
                snapshot = json.loads(payment["items_json"])
                if {i["productId"]: i["quantity"] for i in snapshot} != normalized_items:
                    raise IdempotencyConflictError(
                        "This Idempotency-Key was already used for a different checkout."
                    )
            else:
                product_ids = tuple(normalized_items)
                placeholders = ", ".join("?" for _ in product_ids)
                product_rows = connection.execute(
                    f"SELECT id, name, price FROM products WHERE id IN ({placeholders})", product_ids
                ).fetchall()
                products = {row["id"]: row for row in product_rows}
                missing = sorted(set(product_ids) - set(products))
                if missing:
                    raise UnknownProductError(", ".join(missing))
                snapshot = [
                    {"productId": pid, "productName": products[pid]["name"], "quantity": qty,
                     "unitPrice": products[pid]["price"]}
                    for pid, qty in normalized_items.items()
                ]
                total = sum(i["unitPrice"] * i["quantity"] for i in snapshot)
                transaction_id = f"txn_{uuid4().hex}"
                payment_reference = f"pay_simulated_{uuid4().hex[:16]}"
                created_at = self._timestamp()
                connection.execute(
                    """INSERT INTO payments (payment_reference, transaction_id, idempotency_key, amount,
                        currency, status, items_json, source_platform, created_at)
                       VALUES (?, ?, ?, ?, 'INR', 'SUCCESS', ?, 'MISSIONCART', ?)""",
                    (payment_reference, transaction_id, idempotency_key, total, json.dumps(snapshot), created_at),
                )
                self._append_event(connection, transaction_id, "CHECKOUT_ACCEPTED", "ACCEPTED", None, payment_reference, created_at)
                self._append_event(connection, transaction_id, "PAYMENT_CAPTURED", "SUCCESS", None, payment_reference, created_at)
                payment = connection.execute(
                    "SELECT * FROM payments WHERE payment_reference = ?", (payment_reference,)
                ).fetchone()
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

        if fail_after_payment:
            message = "Injected fault: order creation failed after the payment was captured."
            with self._connection() as failure_connection:
                self._append_event(
                    failure_connection, payment["transaction_id"], "ORDER_CREATION_FAILED", "FAILED",
                    None, payment["payment_reference"], self._timestamp(), detail=message,
                )
            raise OrderCreationFailedError(payment["transaction_id"], payment["payment_reference"], message)

        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            order_id = self._write_order(
                connection, payment, json.loads(payment["items_json"]), "ORDER_CONFIRMED"
            )
            result = self._order_from_connection(connection, order_id)
            connection.commit()
            return result, False
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _write_order(
        self, connection: sqlite3.Connection, payment: sqlite3.Row, items: list[dict[str, object]],
        event_type: str,
    ) -> str:
        """Insert the order for an already-captured payment. Caller owns the transaction."""
        order_id = f"ord_{uuid4().hex}"
        created_at = self._timestamp()
        connection.execute(
            """INSERT INTO orders (id, idempotency_key, status, total, currency, source_platform,
                payment_reference, created_at) VALUES (?, ?, 'CONFIRMED', ?, ?, ?, ?, ?)""",
            (order_id, payment["idempotency_key"], payment["amount"], payment["currency"],
             payment["source_platform"], payment["payment_reference"], created_at),
        )
        connection.executemany(
            """INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price)
               VALUES (?, ?, ?, ?, ?)""",
            [(order_id, i["productId"], i["productName"], i["quantity"], i["unitPrice"]) for i in items],
        )
        connection.execute(
            "UPDATE transaction_events SET order_id = ? WHERE transaction_id = ? AND order_id IS NULL",
            (order_id, payment["transaction_id"]),
        )
        self._append_event(
            connection, payment["transaction_id"], event_type, "SUCCESS", order_id,
            payment["payment_reference"], created_at,
        )
        return order_id

    def _append_event(
        self, connection: sqlite3.Connection, transaction_id: str, event_type: str, state: str,
        order_id: str | None, payment_reference: str, occurred_at: str, detail: str | None = None,
    ) -> None:
        position = connection.execute(
            "SELECT COALESCE(MAX(position), 0) + 1 FROM transaction_events WHERE transaction_id = ?",
            (transaction_id,),
        ).fetchone()[0]
        connection.execute(
            """INSERT INTO transaction_events (id, transaction_id, event_type, position, occurred_at,
                state, source_platform, order_id, payment_reference, detail)
               VALUES (?, ?, ?, ?, ?, ?, 'MISSIONCART', ?, ?, ?)""",
            (f"evt_{uuid4().hex}", transaction_id, event_type, position, occurred_at, state,
             order_id, payment_reference, detail),
        )

    def get_order(self, order_id: str) -> dict[str, object]:
        with self._connection() as connection:
            return self._order_from_connection(connection, order_id)

    def list_orders(self) -> list[dict[str, object]]:
        with self._connection() as connection:
            order_ids = [row["id"] for row in connection.execute(
                "SELECT id FROM orders ORDER BY created_at DESC, id DESC"
            ).fetchall()]
            return [self._order_from_connection(connection, order_id) for order_id in order_ids]

    def list_events(self, order_id: str) -> list[dict[str, str]]:
        with self._connection() as connection:
            self._order_row(connection, order_id)
            return self._events_from_connection(connection, order_id)

    @staticmethod
    def _normalize_items(items: Iterable[tuple[str, int]]) -> dict[str, int]:
        quantities: defaultdict[str, int] = defaultdict(int)
        for product_id, quantity in items:
            if quantity < 1:
                raise ValueError("Each checkout quantity must be at least one.")
            quantities[product_id] += quantity
        if not quantities:
            raise ValueError("At least one checkout item is required.")
        return dict(sorted(quantities.items()))

    def _assert_same_items(
        self, connection: sqlite3.Connection, order_id: str, expected: dict[str, int]
    ) -> None:
        actual = {
            row["product_id"]: row["quantity"]
            for row in connection.execute(
                "SELECT product_id, quantity FROM order_items WHERE order_id = ?", (order_id,)
            ).fetchall()
        }
        if actual != expected:
            raise IdempotencyConflictError(
                "This Idempotency-Key was already used for a different checkout."
            )

    def _order_from_connection(
        self, connection: sqlite3.Connection, order_id: str
    ) -> dict[str, object]:
        order = self._order_row(connection, order_id)
        item_rows = connection.execute(
            """
            SELECT product_id, product_name, quantity, unit_price
            FROM order_items WHERE order_id = ? ORDER BY id
            """,
            (order_id,),
        ).fetchall()
        return {
            "id": order["id"],
            "status": order["status"],
            "total": order["total"],
            "currency": order["currency"],
            "sourcePlatform": order["source_platform"],
            "paymentReference": order["payment_reference"],
            "createdAt": order["created_at"],
            "items": [
                {
                    "productId": item["product_id"],
                    "productName": item["product_name"],
                    "quantity": item["quantity"],
                    "unitPrice": item["unit_price"],
                }
                for item in item_rows
            ],
            "events": self._events_from_connection(connection, order_id),
        }

    @staticmethod
    def _product_from_row(row: sqlite3.Row) -> dict[str, object]:
        product = {
            "id": row["id"],
            "name": row["name"],
            "description": row["description"],
            "category": row["category"],
            "price": row["price"],
            "rating": row["rating"],
            "reviewCount": row["review_count"],
            "image": row["image"],
            "imageAlt": row["image_alt"],
            "highlights": json.loads(row["highlights_json"]),
        }
        if row["badge"] is not None:
            product["badge"] = row["badge"]
        return product

    @staticmethod
    def _timestamp() -> str:
        return datetime.now(UTC).isoformat().replace("+00:00", "Z")

    @staticmethod
    def _order_row(connection: sqlite3.Connection, order_id: str) -> sqlite3.Row:
        order = connection.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        if order is None:
            raise OrderNotFoundError(order_id)
        return order

    @staticmethod
    def _events_from_connection(connection: sqlite3.Connection, order_id: str) -> list[dict[str, str]]:
        rows = connection.execute(
            """
            SELECT id, transaction_id, event_type, occurred_at, state, source_platform,
                   order_id, payment_reference, detail
            FROM transaction_events WHERE order_id = ? ORDER BY occurred_at, position, id
            """,
            (order_id,),
        ).fetchall()
        return [
            {
                "id": row["id"],
                "transactionId": row["transaction_id"],
                "eventType": row["event_type"],
                "occurredAt": row["occurred_at"],
                "state": row["state"],
                "sourcePlatform": row["source_platform"],
                "orderId": row["order_id"],
                "paymentReference": row["payment_reference"],
                "detail": row["detail"],
            }
            for row in rows
        ]
