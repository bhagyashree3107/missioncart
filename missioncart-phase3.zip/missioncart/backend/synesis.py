"""SYNESIS: single-host transaction monitoring, diagnosis and safe recovery.

Reads the same SQLite database MissionCart writes to. Detection compares the authoritative
`payments` table with the `orders` table; it never infers payment failure from an error alone.
"""

from __future__ import annotations

from datetime import UTC, datetime
import json
import os
import sqlite3
from uuid import uuid4

from .database import MissionCartDatabase


class FaultInjectionUnavailableError(PermissionError):
    """Fault injection is not permitted in this environment."""


class IncidentNotFoundError(LookupError):
    pass


class IncidentNotOpenError(ValueError):
    pass


class FaultInjection:
    """Development-only switch. Off by default; cannot be enabled in production."""

    def __init__(self) -> None:
        self.enabled = False

    @staticmethod
    def available() -> bool:
        if os.getenv("SYNESIS_ENV", "development").strip().lower() == "production":
            return False
        return os.getenv("SYNESIS_ENABLE_FAULT_INJECTION", "").strip().lower() in {"1", "true", "yes"}

    def active(self) -> bool:
        return self.enabled and self.available()

    def status(self) -> dict[str, object]:
        return {"available": self.available(), "enabled": self.active()}

    def set(self, enabled: bool) -> dict[str, object]:
        if not self.available():
            self.enabled = False
            raise FaultInjectionUnavailableError(
                "Fault injection is unavailable. It requires SYNESIS_ENABLE_FAULT_INJECTION=true "
                "and SYNESIS_ENV other than 'production'."
            )
        self.enabled = enabled
        return self.status()


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _age_seconds(timestamp: str) -> float:
    return (datetime.now(UTC) - datetime.fromisoformat(timestamp.replace("Z", "+00:00"))).total_seconds()


class SynesisMonitor:
    def __init__(self, database: MissionCartDatabase, grace_seconds: float | None = None):
        self.database = database
        self.grace_seconds = (
            grace_seconds if grace_seconds is not None
            else float(os.getenv("SYNESIS_SCAN_GRACE_SECONDS", "30"))
        )

    # ---------- detection and diagnosis ----------

    def scan(self) -> dict[str, list[str]]:
        created: list[str] = []
        resolved: list[str] = []
        connection = self.database._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            rows = connection.execute(
                """SELECT p.* FROM payments p LEFT JOIN orders o ON o.payment_reference = p.payment_reference
                   WHERE o.id IS NULL AND p.status IN ('SUCCESS', 'PENDING', 'UNKNOWN')
                   ORDER BY p.created_at"""
            ).fetchall()
            for payment in rows:
                failure = connection.execute(
                    """SELECT * FROM transaction_events WHERE transaction_id = ? AND event_type = 'ORDER_CREATION_FAILED'
                       ORDER BY occurred_at, position LIMIT 1""",
                    (payment["transaction_id"],),
                ).fetchone()
                # Give an in-flight checkout time to finish unless a failure was explicitly recorded.
                if failure is None and _age_seconds(payment["created_at"]) < self.grace_seconds:
                    continue
                incident_type = "PAID_NO_ORDER" if payment["status"] == "SUCCESS" else "PAYMENT_STATE_UNCERTAIN"
                if connection.execute(
                    "SELECT 1 FROM incidents WHERE transaction_id = ? AND incident_type = ? AND status = 'OPEN'",
                    (payment["transaction_id"], incident_type),
                ).fetchone():
                    continue
                incident_id = f"inc_{uuid4().hex}"
                summary, cause, evidence = self._diagnose(connection, payment, failure, incident_type)
                connection.execute(
                    """INSERT INTO incidents (id, transaction_id, payment_reference, incident_type, severity,
                        status, summary, probable_cause, evidence_json, detected_at)
                       VALUES (?, ?, ?, ?, 'HIGH', 'OPEN', ?, ?, ?, ?)""",
                    (incident_id, payment["transaction_id"], payment["payment_reference"], incident_type,
                     summary, cause, json.dumps(evidence), _now()),
                )
                created.append(incident_id)
            # An open incident whose order has since appeared (e.g. customer retry) is observed consistent.
            for row in connection.execute(
                """SELECT i.id FROM incidents i JOIN orders o ON o.payment_reference = i.payment_reference
                   WHERE i.status = 'OPEN'"""
            ).fetchall():
                connection.execute(
                    "UPDATE incidents SET status='RESOLVED', resolved_at=?, resolution=? WHERE id=?",
                    (_now(), "OBSERVED_CONSISTENT: an order now exists for this payment (not resolved by SYNESIS recovery).", row["id"]),
                )
                resolved.append(row["id"])
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()
        return {"created": created, "resolved": resolved}

    @staticmethod
    def _diagnose(connection, payment, failure, incident_type):
        events = connection.execute(
            "SELECT event_type FROM transaction_events WHERE transaction_id = ? ORDER BY occurred_at, position",
            (payment["transaction_id"],),
        ).fetchall()
        facts = [
            f"Payments table: {payment['payment_reference']} has status {payment['status']} for "
            f"{payment['currency']} {payment['amount']} at {payment['created_at']}.",
            f"Orders table: no order row exists for payment reference {payment['payment_reference']}.",
            "Recorded events: " + ", ".join(e["event_type"] for e in events) + ".",
        ]
        if incident_type == "PAYMENT_STATE_UNCERTAIN":
            summary = f"Payment {payment['payment_reference']} is {payment['status']} and no order exists"
            cause = (f"The payment outcome is {payment['status']}, so SYNESIS cannot establish whether the customer "
                     "was charged. Recovery is blocked until the payment state is confirmed as SUCCESS.")
        elif failure is not None:
            facts.append(f"Event ORDER_CREATION_FAILED at {failure['occurred_at']}: {failure['detail'] or 'no detail recorded'}")
            summary = f"Payment succeeded but order creation failed ({payment['payment_reference']})"
            cause = ("Order creation failed after the payment was captured. The failure event, the "
                     "SUCCESS payment record and the missing order row agree. This is evidence-based, not proof of "
                     "the underlying code defect.")
        else:
            facts.append(f"No ORDER_CONFIRMED or failure event; payment is {int(_age_seconds(payment['created_at']))}s old.")
            summary = f"Payment succeeded but no order was created ({payment['payment_reference']})"
            cause = ("The order step did not complete (crash, timeout or lost response). No failure "
                     "event was recorded, so the exact reason is unknown.")
        return summary, cause, {"facts": facts}

    # ---------- read models for the dashboard ----------

    def overview(self) -> dict[str, object]:
        with self.database._connection() as c:
            def one(sql: str) -> int:
                return c.execute(sql).fetchone()[0]
            counts = {
                "transactions": one("SELECT COUNT(*) FROM payments"),
                "ordersConfirmed": one("SELECT COUNT(*) FROM orders WHERE status = 'CONFIRMED'"),
                "paidWithoutOrder": one(
                    """SELECT COUNT(*) FROM payments p LEFT JOIN orders o ON o.payment_reference = p.payment_reference
                       WHERE o.id IS NULL AND p.status = 'SUCCESS'"""),
                "openIncidents": one("SELECT COUNT(*) FROM incidents WHERE status = 'OPEN'"),
                "resolvedIncidents": one("SELECT COUNT(*) FROM incidents WHERE status = 'RESOLVED'"),
                "recoveryAttempts": one("SELECT COUNT(*) FROM recovery_attempts"),
                "verifiedRecoveries": one("SELECT COUNT(*) FROM recovery_attempts WHERE outcome = 'SUCCEEDED' AND verified = 1"),
            }
            transactions = []
            for r in c.execute(
                """SELECT p.transaction_id, p.payment_reference, p.status AS payment_status, p.amount, p.currency,
                          p.source_platform, p.created_at, o.id AS order_id, o.status AS order_status,
                          (SELECT i.id FROM incidents i WHERE i.transaction_id = p.transaction_id
                           ORDER BY i.detected_at DESC LIMIT 1) AS incident_id
                   FROM payments p LEFT JOIN orders o ON o.payment_reference = p.payment_reference
                   ORDER BY p.created_at DESC LIMIT 50""").fetchall():
                if r["payment_status"] == "SUCCESS" and r["order_status"] == "CONFIRMED":
                    consistency = "CONSISTENT"
                elif r["order_id"] is None and r["payment_status"] in ("SUCCESS", "PENDING", "UNKNOWN"):
                    consistency = "MISMATCH"
                else:
                    consistency = "OTHER"
                transactions.append({
                    "transactionId": r["transaction_id"], "paymentReference": r["payment_reference"],
                    "paymentStatus": r["payment_status"], "amount": r["amount"], "currency": r["currency"],
                    "sourcePlatform": r["source_platform"], "timestamp": r["created_at"],
                    "orderId": r["order_id"], "orderStatus": r["order_status"] or "MISSING",
                    "consistency": consistency, "incidentId": r["incident_id"],
                })
            incidents = [self._incident(r) for r in c.execute(
                "SELECT * FROM incidents ORDER BY detected_at DESC LIMIT 50").fetchall()]
            events = [self._event(r) for r in c.execute(
                "SELECT * FROM transaction_events ORDER BY occurred_at DESC, position DESC LIMIT 30").fetchall()]
        return {"counts": counts, "transactions": transactions, "incidents": incidents, "recentEvents": events}

    def incident_detail(self, incident_id: str) -> dict[str, object]:
        with self.database._connection() as c:
            row = c.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
            if row is None:
                raise IncidentNotFoundError(incident_id)
            payment = c.execute("SELECT * FROM payments WHERE payment_reference = ?", (row["payment_reference"],)).fetchone()
            order = c.execute("SELECT id, status, total FROM orders WHERE payment_reference = ?", (row["payment_reference"],)).fetchone()
            timeline = [self._event(r) for r in c.execute(
                "SELECT * FROM transaction_events WHERE transaction_id = ? ORDER BY occurred_at, position, id",
                (row["transaction_id"],)).fetchall()]
            attempts = [
                {"id": a["id"], "attemptedAt": a["attempted_at"], "outcome": a["outcome"], "reason": a["reason"],
                 "orderId": a["order_id"], "verified": bool(a["verified"])}
                for a in c.execute("SELECT * FROM recovery_attempts WHERE incident_id = ? ORDER BY attempted_at", (incident_id,)).fetchall()]
            return {
                "incident": self._incident(row), "timeline": timeline, "attempts": attempts,
                "payment": dict(payment) | {"items_json": None} if payment else None,
                "order": dict(order) if order else None,
            }

    @staticmethod
    def _incident(r) -> dict[str, object]:
        return {
            "id": r["id"], "transactionId": r["transaction_id"], "paymentReference": r["payment_reference"],
            "type": r["incident_type"], "severity": r["severity"], "status": r["status"], "summary": r["summary"],
            "probableCause": r["probable_cause"], "evidence": json.loads(r["evidence_json"])["facts"],
            "detectedAt": r["detected_at"], "resolvedAt": r["resolved_at"], "resolution": r["resolution"],
        }

    @staticmethod
    def _event(r) -> dict[str, object]:
        return {
            "id": r["id"], "transactionId": r["transaction_id"], "eventType": r["event_type"],
            "occurredAt": r["occurred_at"], "state": r["state"], "sourcePlatform": r["source_platform"],
            "orderId": r["order_id"], "paymentReference": r["payment_reference"], "detail": r["detail"],
        }

    # ---------- safe recovery ----------

    def recover(self, incident_id: str, fault_active: bool = False) -> dict[str, object]:
        """Retry order creation only. Never creates a payment. Resolves only after verifying DB state."""
        connection = self.database._connect()
        outcome, reason, order_id = "FAILED", "", None
        try:
            connection.execute("BEGIN IMMEDIATE")
            incident = connection.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
            if incident is None:
                raise IncidentNotFoundError(incident_id)
            if incident["status"] != "OPEN":
                raise IncidentNotOpenError("Incident is not open.")
            payment = connection.execute(
                "SELECT * FROM payments WHERE payment_reference = ?", (incident["payment_reference"],)
            ).fetchone()
            existing = connection.execute(
                "SELECT id FROM orders WHERE payment_reference = ? OR idempotency_key = ?",
                (incident["payment_reference"], payment["idempotency_key"] if payment else ""),
            ).fetchone()
            items = json.loads(payment["items_json"]) if payment else []
            if payment is None or payment["status"] != "SUCCESS":
                outcome = "BLOCKED"
                reason = (f"Payment status is {payment['status'] if payment else 'missing'}; recovery requires an "
                          "authoritative SUCCESS payment. No order created.")
            elif existing is not None:
                order_id = existing["id"]
                ok, checks = self._verify(connection, payment)
                outcome = "SUCCEEDED" if ok else "FAILED"
                reason = "Order already existed; nothing was created. Verification: " + checks
            elif fault_active:
                reason = "Order creation is still failing (fault injection active). No order created; payment untouched."
            elif not items:
                outcome, reason = "BLOCKED", "No item snapshot stored for this payment; cannot rebuild the order."
            else:
                order_id = self.database._write_order(connection, payment, items, "RECOVERY_ORDER_CREATED")
                ok, checks = self._verify(connection, payment)
                if ok:
                    outcome, reason = "SUCCEEDED", "Order created from the stored payment snapshot (no new payment). Verification: " + checks
                else:
                    connection.rollback()
                    connection.execute("BEGIN IMMEDIATE")
                    order_id, reason = None, "Final-state verification failed, order rolled back. " + checks
            verified = 1 if outcome == "SUCCEEDED" else 0
            connection.execute(
                "INSERT INTO recovery_attempts (id, incident_id, attempted_at, outcome, reason, order_id, verified) VALUES (?,?,?,?,?,?,?)",
                (f"rec_{uuid4().hex}", incident_id, _now(), outcome, reason, order_id, verified),
            )
            if outcome == "SUCCEEDED":
                connection.execute(
                    "UPDATE incidents SET status='RESOLVED', resolved_at=?, resolution=? WHERE id=?",
                    (_now(), "RECOVERED: order verified against payment record.", incident_id),
                )
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()
        return {"outcome": outcome, "reason": reason, "orderId": order_id, "incident": self.incident_detail(incident_id)["incident"]}

    @staticmethod
    def _verify(connection: sqlite3.Connection, payment: sqlite3.Row) -> tuple[bool, str]:
        orders = connection.execute("SELECT * FROM orders WHERE payment_reference = ?", (payment["payment_reference"],)).fetchall()
        payments = connection.execute("SELECT COUNT(*) FROM payments WHERE transaction_id = ?", (payment["transaction_id"],)).fetchone()[0]
        checks = {"exactly one order for the payment": len(orders) == 1, "exactly one payment record": payments == 1}
        if len(orders) == 1:
            o = orders[0]
            qty = connection.execute("SELECT COALESCE(SUM(quantity*unit_price),0) FROM order_items WHERE order_id=?", (o["id"],)).fetchone()[0]
            checks["order CONFIRMED"] = o["status"] == "CONFIRMED"
            checks["order total equals payment amount"] = o["total"] == payment["amount"]
            checks["same idempotency key"] = o["idempotency_key"] == payment["idempotency_key"]
            if json.loads(payment["items_json"]):
                checks["item lines sum to payment amount"] = qty == payment["amount"]
        return all(checks.values()), "; ".join(f"{k}: {'ok' if v else 'FAILED'}" for k, v in checks.items())
